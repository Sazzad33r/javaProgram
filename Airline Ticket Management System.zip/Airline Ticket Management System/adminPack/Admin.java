package adminPack;

import java.io.*;
import java.util.*;

public class Admin {

    int flightNumber;
    String date;
    String time;
    String from;
    String to;
    Scanner in = new Scanner(System.in);

    public int addFlight() {
        System.out.print("Enter Flight Number: ");
        flightNumber = in.nextInt();
        System.out.print("Enter Date: ");
        in.nextLine();
        date = in.nextLine();
        System.out.print("Enter Time: ");
        time = in.nextLine();
        System.out.print("Enter Departing City: ");
        from = in.nextLine();
        System.out.print("Enter Arrival City: ");
        to = in.nextLine();

        try {
            File flight = new File(System.getProperty("user.dir"), "/files/flight.txt");
            if (!flight.exists()) {
                flight.createNewFile();
            }

            FileWriter fw = new FileWriter("files/flight.txt", true);
            fw.write(String.valueOf(flightNumber) + "#" + date + "#" + time + "#" + from + "#" + to + "\n");

            fw.close();

            return 1;

        } catch (Exception e) {
            return 0;
        }
    }

    public int removeFlight(int flightNumberParam) {
        File flight = new File(System.getProperty("user.dir"), "/files/flight.txt");
        File tempFlight = new File(System.getProperty("user.dir"), "/files/tempFlight.txt");

        try {
            tempFlight.createNewFile();
        } catch (Exception e) {
            return 0;
        }

        try {
            Scanner fr = new Scanner(flight);
            FileWriter fw = new FileWriter("files/tempFlight.txt");

            while (fr.hasNext()) {
                String temp = fr.nextLine();
                if (temp.contains(String.valueOf(flightNumberParam))) {
                    continue;
                }
                fw.write(temp + "\n");
            }
            fw.close();
            fr.close();

            flight.delete();
            flight.createNewFile();

            try {
                Scanner fr2 = new Scanner(tempFlight);
                FileWriter fw2 = new FileWriter("files/flight.txt");

                while (fr2.hasNext()) {
                    fw2.write(fr2.nextLine() + "\n");
                }

                fw2.close();
                fr2.close();
            } catch (Exception e) {
                System.out.println(e.toString() + "\n" + "125");
            }

            tempFlight.delete();
            return 1;

        } catch (Exception e) {
            System.out.println("Booking Number Update Unsuccessful!!!\n" + e.toString());
            return 0;
        }
    }
}