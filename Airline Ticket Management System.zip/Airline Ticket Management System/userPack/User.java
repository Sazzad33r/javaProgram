package userPack;

import java.io.*;
import java.util.Scanner;

interface UserWork {
	int checkUser(String userName, String pswd);

	int createUser(int userID, String userName, String password, String Address, String contactNumber,
			int numberOfBooking);
}

public class User implements UserWork {
	private String userName;
	private String password;
	private int userID;
	private String address;
	private int numberOfBooking;
	private String contactNumber;

	// constructor
	public User(int idUser) {
		setUserID(idUser);
	}

	public User() {
		setUserID(0);
	}

	// setter & getter of UserName
	public void setUserName(String name) {
		userName = name;
	}

	public String getUserName() {
		return userName;
	}

	// setter & getter of Password
	public void setPassword(String pswd) {
		password = pswd;
	}

	public String getPassword() {
		return password;
	}

	// setter & getter of UserID
	public void setUserID(int ID) {
		userID = ID;
	}

	public int getUserID() {
		return userID;
	}

	// setter & getter of address
	public void setAddress(String adrs) {
		address = adrs;
	}

	public String getAddress() {
		return address;
	}

	// setter & getter of booking number
	public void setNumberBooking(int noOfBok) {
		numberOfBooking = noOfBok;
	}

	public int getNumberBooking() {
		return numberOfBooking;
	}

	// setter & getter of contact number
	public void setContact(String contNum) {
		contactNumber = contNum;
	}

	public String getContact() {
		return contactNumber;
	}

	public int updateNumberBooking() {
		File user = new File(System.getProperty("user.dir"), "/files/user.txt");
		File tempUser = new File(System.getProperty("user.dir"), "/files/tempUser.txt");

		try {
			tempUser.createNewFile();
		} catch (Exception e) {
			return 0;
		}

		try {
			Scanner fr = new Scanner(user);
			FileWriter fw = new FileWriter("files/tempUser.txt");

			while (fr.hasNext()) {
				String temp = fr.nextLine();
				if (temp.contains(String.valueOf(userID)) && temp.contains(getUserName())) {
					String[] userIn = temp.split("#", 6);
					int tempBooking = Integer.parseInt(userIn[5]);
					tempBooking++;
					temp = userIn[0] + "#" + userIn[1] + "#" + userIn[2] + "#" + userIn[3] + "#" + userIn[4] + "#"
							+ String.valueOf(tempBooking);
				}
				fw.write(temp + "\n");

			}
			fw.close();
			fr.close();

			user.delete();
			user.createNewFile();

			try {
				Scanner fr2 = new Scanner(tempUser);
				FileWriter fw2 = new FileWriter("files/user.txt");

				while (fr2.hasNext()) {
					fw2.write(fr2.nextLine() + "\n");
				}

				fw2.close();
				fr2.close();
			} catch (Exception e) {
				System.out.println(e.toString() + "\n" + "125");
			}

			tempUser.delete();
			return 1;

		} catch (Exception e) {
			System.out.println("Booking Number Update Unsuccessful!!!\n" + e.toString());
			return 0;
		}

	}

	// interface implementation
	public int checkUser(String userName, String pswd) {

		int userID;
		String userInfo;
		File user = new File(System.getProperty("user.dir"), "/files/user.txt");

		if (user.exists()) {
			try {
				Scanner fr = new Scanner(user);

				while (fr.hasNext()) {
					userInfo = fr.nextLine();

					String[] userIn = userInfo.split("#", 6);

					if (userName.equals(userIn[1]) && pswd.equals(userIn[2])) {
						userID = Integer.parseInt(userIn[0]);

						setUserName(userIn[1]);
						setPassword(userIn[2]);
						setUserID(Integer.parseInt(userIn[0]));
						setAddress(userIn[3]);
						setContact(userIn[4]);
						setNumberBooking(Integer.parseInt(userIn[5]));
						fr.close();
						return userID;
					}
				}
				fr.close();
			} catch (Exception e) {
				System.out.println(e.toString() + "171 user");
			}
		}
		return 0;
	}

	public int createUser(int userID, String userName, String password, String Address, String contactNumber,
			int numberOfBooking) {

		try {
			File user = new File(System.getProperty("user.dir"), "/files/user.txt");
			if (!user.exists()) {
				user.createNewFile();
			}

			FileWriter fw = new FileWriter("files/user.txt", true);

			fw.write(Integer.toString(userID) + "#" + userName + "#" + password + "#" + Address + "#" + contactNumber
					+ "#"
					+ Integer.toString(numberOfBooking) + "\n");

			fw.close();
		} catch (Exception e) {
			return 0;
		}
		return 1;
	}

	public int userBooking(int flightID) {
		try {
			File user = new File(System.getProperty("user.dir"), "/files/userFlightMap.txt");
			if (!user.exists()) {
				user.createNewFile();
			}

			FileWriter fw = new FileWriter("files/userFlightMap.txt", true);
			fw.write(String.valueOf(flightID) + "#" + String.valueOf(getUserID()) + "\n");

			fw.close();

			return 1;

		} catch (Exception e) {
			return 0;
		}
	}
}