import java.util.Scanner;
import java.lang.*;
import java.rmi.server.UID;

import userPack.*;
import java.io.*;
import adminPack.*;

public class Start {

    static int userID;
    static Scanner in = new Scanner(System.in);
    static int[] flightID;
    static int init = 0;
    static int noOfFlight = 0;

    public static void main(String[] args) {

        int role;
        int createUser = 0;

        System.out.println("\n\n\nWelcome to ZZZ Air Line Ticket Booking System\n");
        displayFlight();
        System.out.print("\n");
        displayOption();
        System.out.print("Enter Choice: ");
        role = in.nextInt();

        while (true) {

            if (role == 1) {
                int result;
                User obj = new User();
                result = inputAndLogin(obj);
                if (result == 0) {
                    System.out.println("User Not Found!!! Try Again!!!");
                    displayOption();
                } else {
                    userID = result;
                    loggedUserMenu(obj);
                    displayOption();
                }

            } else if (role == 2) {
                createUser = inputAndTransferUser();
                if (createUser == 1) {
                    changeUserIDValue();
                    System.out.println("User Created successfully.");

                    displayOption();

                }
            } else if (role == 3) {
                Console cnsl = System.console();
                System.out.print("Enter Password: ");
                char[] tempPassword = cnsl.readPassword();
                String pass = String.copyValueOf(tempPassword);
                if (pass.contains("adminRifat123")) {
                    adminPanel();
                    displayFlight();
                } else {
                    System.out.println("Wrong Password");
                }
                displayOption();
            } else if (role == 4) {
                System.out.println("Thanks for using the software... Exiting...");
                in.close();
                break;
            } else {
                System.out.println("Invalid Input");
                displayOption();
            }

            // in.nextLine();
            System.out.print("Enter Choice: ");
            role = in.nextInt();
        }

    }

    public static void displayOption() {
        System.out.printf("\n");
        System.out.print("Options\n");
        System.out.println(
                "Press 1 for User Login\nPress 2 for User Signup\nPress 3 for Admin Login\nPress 4 to Exit\n");
    }

    public static int getUserID() {

        String userIDString;
        int userID = -1;

        try {
            File id = new File(System.getProperty("user.dir"), "/files/id.txt");

            if (!id.exists()) {
                id.createNewFile();
                FileWriter fw = new FileWriter("files/id.txt");
                fw.write("0");
                fw.close();
            }

            Scanner fr = new Scanner(id);
            userIDString = fr.nextLine();
            userID = Integer.parseInt(userIDString);
            userID++;

            fr.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }

        return userID;
    }

    public static int inputAndLogin(User obj) {

        String userName, password;
        Console cnsl = System.console();

        in.nextLine();
        System.out.print("Enter User Name: ");
        userName = in.nextLine();

        System.out.print("Enter Password: ");
        char[] tempPassword = cnsl.readPassword();

        password = String.copyValueOf(tempPassword);

        userID = obj.checkUser(userName, password);

        return userID;
    }

    public static int inputAndTransferUser() {

        int result;
        String userName, password, address, contactNumber;
        int numberOfBooking;

        Console cnsl = System.console();

        userID = getUserID();

        User obj = new User(userID);

        in.nextLine();
        System.out.print("Enter User Name: ");
        userName = in.nextLine();
        System.out.print("Enter Password: ");
        char[] tempPassword = cnsl.readPassword();

        password = String.copyValueOf(tempPassword);

        System.out.print("Enter Address: ");
        address = in.nextLine();

        System.out.print("Enter Contact Number: ");
        contactNumber = in.nextLine();

        numberOfBooking = 0;

        result = obj.createUser(userID, userName, password, address, contactNumber, numberOfBooking);

        return result;
    }

    public static void changeUserIDValue() {

        try {
            File id = new File(System.getProperty("user.dir"), "/files/id.txt");

            if (id.exists()) {
                id.delete();
                id.createNewFile();

                int uID = userID;
                FileWriter fw = new FileWriter("files/id.txt");
                fw.write(String.valueOf(uID));
                fw.close();
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public static void displayFlight() {
        int flag = 0;
        if (init != 0) {
            flightID = new int[noOfFlight];
        }
        System.out.println("\n");
        String flightInfo;

        File flight = new File(System.getProperty("user.dir"), "/files/flight.txt");

        if (flight.exists()) {

            try {
                Scanner fr = new Scanner(flight);
                while (fr.hasNext()) {
                    flightInfo = fr.nextLine();

                    String[] flightIn = flightInfo.split("#", 5);

                    System.out.println("     Flight Number: " + flightIn[0]);
                    System.out.println("     Flight Date  : " + flightIn[1]);
                    System.out.println("     Flight Time  : " + flightIn[2]);
                    System.out.println("     From         : " + flightIn[3]);
                    System.out.println("     To           : " + flightIn[4]);
                    System.out.println();
                    if (init == 0) {
                        noOfFlight++;
                    } else {
                        flightID[flag++] = Integer.parseInt(flightIn[0]);
                    }
                }
                init++;
                fr.close();
            } catch (Exception e) {
                System.out.println("Something went wrong.");
            }
        } else {
            System.out.println("No Flight Information Available");
        }

    }

    public static void loggedUserMenu(User obj) {

        int choice;
        System.out.println("\n\nWelcome Mr/Mrs " + obj.getUserName());
        System.out.println("User ID            : " + String.valueOf(obj.getUserID()));
        System.out.println("User Name          : " + obj.getUserName());
        System.out.println("User Contact       : " + obj.getContact());
        System.out.println("User Address       : " + obj.getAddress());
        System.out.println("User Booking Number: " + String.valueOf(obj.getNumberBooking()));

        displayFlight();
        /*
         * for(int counter: flightID){
         * System.out.println(counter + "\n");
         * }
         */
        System.out.println("\n");
        loggedUserDisplay();
        choice = in.nextInt();
        while (true) {
            if (choice == 1) {
                int success;
                System.out.print("Enter Flight Number: ");
                int flightNumber = in.nextInt();
                int rightFlightNumber = 0;
                for (int flNum : flightID) {
                    if (flNum == flightNumber) {
                        rightFlightNumber = 1;
                    }
                }
                if (rightFlightNumber == 1) {
                    success = obj.userBooking(flightNumber);
                    if (success == 1) {
                        int done = obj.updateNumberBooking();
                        if (done == 1) {
                            System.out.println("\nBooking Successful!!!\n");
                        } else {
                            System.out.println("\nSomething Went Wrong!!!\n");
                        }
                    } else {
                        System.out.println("\nSomething Went Wrong!!!\n");
                    }
                } else {
                    System.out.println("Wrong Flight Number");
                }
            } else if (choice == 2) {
                return;
            } else {
                System.out.println("Invalid Input!!!");
            }

            loggedUserDisplay();
            in.nextLine();
            choice = in.nextInt();
        }
    }

    public static void loggedUserDisplay() {
        System.out.println("Press 1 To Book a Flight\nPress 2 To Log Out");
        System.out.print("Enter Choice: ");
    }

    public static void adminPanel() {
        int choice = 0;
        while (true) {
            System.out.println("\nPress 1 To Add Flight\nPress 2 To Remove Flight\nPress 3 To Log out\n\n");
            System.out.print("Enter Your Choice: ");
            choice = in.nextInt();
            if (choice == 1) {
                Admin objAdmin = new Admin();
                int success = objAdmin.addFlight();
                if (success == 1) {
                    System.out.println("\nFlight Added Successfully.\n");
                } else {
                    System.out.println("\nSomething Went Wrong\n");
                }
            } else if (choice == 2) {
                Admin objAdmin = new Admin();
                displayFlight();
                System.out.print("Enter Flight Number: ");
                int flightNumber = in.nextInt();
                int rightFlightNumber = 0;
                for (int flNum : flightID) {
                    System.out.println(flNum);
                    if (flNum == flightNumber) {
                        rightFlightNumber = 1;
                    }
                }
                if (rightFlightNumber == 1) {
                    int success = objAdmin.removeFlight(flightNumber);
                    if (success == 1) {
                        System.out.println("\nFlight deleted Successfully.\n");
                        init = 0;
                    } else {
                        System.out.println("\nSomething Went Wrong\n");
                    }
                } else {
                    System.out.println("Invalid Flight Number!!!");
                }
            } else if (choice == 3) {
                return;
            } else {
                System.out.println("Wrong Input!!!");
            }
        }
    }
}