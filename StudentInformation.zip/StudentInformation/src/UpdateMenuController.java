/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sazzad
 */
public class UpdateMenuController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnUBClick(ActionEvent event) throws IOException {
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("UpdateBackground.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Update Background Menu");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void btnUGclick(ActionEvent event) throws IOException {
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("UpdateGrade.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Update Grade Menu");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void btnMMClick(ActionEvent event) throws IOException {
        
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Main Menu");
        stage.setScene(scene);
        stage.show();
    }
    
}
