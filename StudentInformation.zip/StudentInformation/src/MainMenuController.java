/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sazzad
 */
public class MainMenuController implements Initializable {

    @FXML
    private AnchorPane mainMenu;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnAdd(ActionEvent event) throws IOException {
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("StudentInfo.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Add Menu");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void btnUpdate(ActionEvent event) throws IOException {
        
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("UpdateMenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Update Menu");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void btnView(ActionEvent event) throws IOException {
        
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("ViewMenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("View Menu");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void btnLogout(ActionEvent event) throws IOException {
        
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Welcome");
        stage.setScene(scene);
        stage.show();
    }
    
}
